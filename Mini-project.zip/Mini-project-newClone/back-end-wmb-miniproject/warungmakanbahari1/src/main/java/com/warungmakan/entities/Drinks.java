package com.warungmakan.entities;

import javax.persistence.*;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "drinks")
public class Drinks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "drink_name")
    private  String name;

    @Column(name = "drink_stock")
    private Integer stock;

    @Column(name = "drink_price")
    private Integer price;

    @OneToMany(mappedBy = "itemDrinks")
    private List<OrderDetail> listItemDrinks;


    public Drinks(){}

    public Integer getId() {
        return id;
    }

    public Drinks setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getNama() {
        return name;
    }

    public Drinks setNama(String nama) {
        this.name = nama;
        return this;
    }

    public Integer getStock() {
        return stock;
    }

    public Drinks setStock(Integer stock) {
        this.stock = stock;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public Drinks setPrice(Integer price) {
        this.price = price;
        return this;
    }

}
