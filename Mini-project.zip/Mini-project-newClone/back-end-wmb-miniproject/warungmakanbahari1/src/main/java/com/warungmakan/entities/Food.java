package com.warungmakan.entities;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
@Table(name = "food")
public class Food {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "food_name")
    private String name;

    @Column(name = "food_stock")
    private Integer stock;

    @Column(name = "food_price")
    private Integer price;


    public Food() {
    }

    public Integer getId() {
        return id;
    }

    public Food setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Food setName(String name) {
        this.name = name;
        return this;
    }

    public Integer getStock() {
        return stock;
    }

    public Food setStock(Integer stock) {
        this.stock = stock;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public Food setPrice(Integer price) {
        this.price = price;
        return this;
    }
}
