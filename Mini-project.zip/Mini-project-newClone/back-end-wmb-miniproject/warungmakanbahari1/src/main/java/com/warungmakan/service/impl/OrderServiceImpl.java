package com.warungmakan.service.impl;

import com.warungmakan.entities.*;
import com.warungmakan.repositories.TableRepository;
import com.warungmakan.repositories.OrderRepository;
import com.warungmakan.service.FoodService;
import com.warungmakan.service.TableService;
import com.warungmakan.service.DrinkService;
import com.warungmakan.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

public class OrderServiceImpl implements OrderService {

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    TableService tableService;

    @Autowired
    TableRepository mejaRepo;

    @Autowired
    FoodService foodService;

    @Autowired
    DrinkService drinkService;

    @Override
    public List<Order> findAll() {
        return orderRepository.findAll();
    }

    @Override
    public Order findById(Integer id) throws Exception{
        if (findAll().isEmpty()) {
            throw new Exception("List Not Found");
        } else {
            for (int i = 0; i < findAll().size(); i++) {
                Order index = findAll().get(i);
                if (index.getId() == id) {
                    return index;
                }
            }
        }
        throw new Exception("Id Not Found");
    }

    public void validCreateOrder(Order order)throws Exception {
        Table table = tableService.findById(order.getTable().getId());
        if (table == null) {
            throw new Exception("table not found");
        } else if (table.getStatusTable().equals("booked")) {
            throw new Exception("table on booked");
        } else if (order.getQuantityCustomer() > table.getChairsAmount()) {
            throw new Exception("the number of seats exceeds the capacity");
        }
        table.setStatusTable("booked");
        tableService.save(table);
    }

    @Override
    public Order save(Order order) throws Exception {
        order.setStatusTransaction("dipesan");
        validCreateOrder(order);
        Integer total = 0;

        for (OrderDetail detail : order.getOrderDetails()) {
            detail.setOrderDetail(order);
            detail.setId(order.getId());
            Food makan = foodService.findById(detail.getItemFood().getId());
            Drinks minum = drinkService.findById(detail.getItemMinuman().getId());
            detail.setItemFood(makan);
            detail.setItemMinuman(minum);
            Integer subTotalMakan = detail.getItemFood().getPrice() * detail.getQuantityFood();
            Integer subTotalMinum = detail.getItemMinuman().getPrice() * detail.getQuantityDrink();
            Integer subTotal = subTotalMakan + subTotalMinum;
            detail.setSubTotal(subTotal);
            total += subTotal;
        }
        order.setPriceTotal(total);
        return orderRepository.save(order);
    }

    @Override
    public void delete(Integer id) {
        orderRepository.deleteById(id);
    }
}
//        List <Order> meja =  orderRepository.findAll();
//        List <Transaksi> transaksiList = transaksiRepository.findAll();
//
//        for (Order p : meja) {
//            Order table = p;
//
//            for (Transaksi transaksi : transaksiList) {
//            Transaksi trans = transaksi;
//
//            if (trans.getPesanan().getId()==pesanan.getId()){
//                if (trans.getStatusTransaction().equals(1)){
//                    if (table.getTable().getId() == pesanan.getTable().getId()) {
//                        throw new Exception("meja sudah dipesan");
//                    }
//                }else {
//                    break;
//                }
//            }
//        }

//            if (pesanan.getQuantityCustomer() > pesanan.getTable().getJumlahKursi())
//                throw new Exception("tamu melebihi kapasitas kursi");
//        }
//        return orderRepository.save(pesanan);
//    }
//}
