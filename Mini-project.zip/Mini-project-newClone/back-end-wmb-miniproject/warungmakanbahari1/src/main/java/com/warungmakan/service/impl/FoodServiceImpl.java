package com.warungmakan.service.impl;

import com.warungmakan.entities.Food;
import com.warungmakan.repositories.FoodRepository;
import com.warungmakan.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class FoodServiceImpl implements FoodService {

    @Autowired
    FoodRepository foodRepository;

    @Override
    public List<Food> findAll() {
        return foodRepository.findAll();
    }

    @Override
    public Food findById(Integer id) {
        return foodRepository.getOne(id);
    }

    @Override
    public Food save(Food food) {
        return foodRepository.save(food);
    }

    @Override
    public void delete(Integer id) {
        foodRepository.deleteById(id);
    }
}
