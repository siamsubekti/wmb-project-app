//package com.warungmakan.service.impl;
//
//import com.warungmakan.entities.Table;
//import com.warungmakan.repositories.TableRepository;
//import com.warungmakan.repositories.TransaksiRepository;
//import com.warungmakan.service.TableService;
//import com.warungmakan.service.DrinkService;
//import com.warungmakan.service.OrderService;
//import com.warungmakan.service.TransaksiService;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.util.List;
//
//public class TransaksiServiceImpl implements TransaksiService {
//
//    @Autowired
//    TransaksiRepository transaksiRepository;
//
//    @Autowired
//    TransaksiService transaksiService;
//
//    @Autowired
//    TableRepository mejaRepo;
//
//    @Autowired
//    TableService tableService;
//
//    @Autowired
//    OrderService pesananService;
//
//    @Autowired
//    DrinkService drinkService;
//
//    @Override
//    public List<Transaksi> findAll() {
//        return transaksiRepository.findAll();
//    }
//
//    @Override
//    public Transaksi save(Transaksi transaksi) throws Exception {
//            Table meja = tableService.findById(transaksi.getPesanan().getTable().getId());
//            if (transaksi.getPesanan().getTable().getId().equals(meja.getId())) {
//                meja.setTable("dipesan");
//            } if (meja.getTable().equalsIgnoreCase("dipesan")) {
//                throw new Exception("meja sudah dipesan");
//            } if (transaksi.getStatusTransaction().equalsIgnoreCase("dibayar")) {
//                meja.setTable("tersedia");
//            }
//        return transaksiRepository.save(transaksi);
//        }
//
//
//    @Override
//    public Transaksi findById(Integer id) throws Exception {
//        if (findAll().isEmpty()) {
//            throw new Exception("id not found");
//        } else {
//            for (int i = 0; i < findAll().size(); i++) {
//                Transaksi
//                if ()
//            }
//
//        return transaksiRepository.getOne(id);
//    }
//
//    @Override
//    public Transaksi update(Transaksi transaksi, Integer id) throws Exception {
//        return null;
//    }
//
//    @Override
//    public void delete(Integer id) {
//
//    }
//}
//        Transaksi newOrder = new Transaksi();
//        newOrder.getPesanan()

//        StatusMeja dipesan = statusMejaRepository.findById(1).get();
//        StatusMeja tersedia = statusMejaRepository.findById(2).get();
//        Table meja = transaksi.getPesanan().getTable();

//        if (transaksi.getStatusTransaction().equals(1)) {
//            statusMeja.setTersedia(statusMeja.getTersedia() - 1);
//            statusMeja.setDipesan(statusMeja.getDipesan() + 1);
//            transaksi.getPesanan().getTable().setStatusTable(statusMejaRepository.getOne(1));
//        }else if (transaksi.getStatusTransaction().equals(2)){
//            statusMeja.setTersedia(statusMeja.getTersedia() + 1);
//            statusMeja.setDipesan(statusMeja.getDipesan() - 1);
//            transaksi.getPesanan().getTable().setStatusTable(statusMejaRepository.getOne(2));
//        }

//        Integer totalMakanan = newOrder.getPesanan().getJumlahMakanan() * newOrder.getPesanan().getMakanan().getPrice();
//        Integer totalMinuman = newOrder.getPesanan().getJumlahMinuman() * newOrder.getPesanan().getMinuman().getPrice();
//        newOrder.setPriceTotal(totalMakanan+totalMinuman);
//        return transaksiRepository.save(newOrder);
//    }

