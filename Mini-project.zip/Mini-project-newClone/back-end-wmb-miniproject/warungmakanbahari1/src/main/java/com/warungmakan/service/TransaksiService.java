//package com.warungmakan.service;
//
//import java.util.List;
//
//public interface TransaksiService {
//
//    List<Transaksi> findAll();
//    Transaksi findById(Integer id) throws Exception;
//    Transaksi save(Transaksi transaksi) throws Exception;
//    Transaksi update(Transaksi transaksi, Integer id) throws Exception;
//
//    void delete (Integer id);
//
//}
