package com.warungmakan.service.impl;

import com.warungmakan.entities.Table;
import com.warungmakan.repositories.OrderRepository;
import com.warungmakan.repositories.TableRepository;
import com.warungmakan.service.TableService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class TableServiceImpl implements TableService {

    @Autowired
    TableRepository tableRepository;

    @Autowired
    OrderRepository orderRepository;

    @Override
    public List<Table> findAll() {
        return tableRepository.findAll();
    }

    @Override
    public Table findById(Integer id) {
        return tableRepository.findByid(id);
    }

    @Override
    public Table save(Table table) {
        return tableRepository.save(table);
    }

    @Override
    public void delete(Integer id) {

    }
}



