package com.warungmakan.entities;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.persistence.Table;
import java.util.List;


@Entity
@Table(name = "cashier")
public class Cashier {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "cashier_name")
    private  String name;

    @Column(name = "password")
    private Integer password;

    @JsonIgnore
    @OneToMany(mappedBy = "cashier", cascade = CascadeType.ALL)
    private List<Order> listOrderCashier;

    public Cashier(){}

    public Integer getId() {
        return id;
    }

    public Cashier setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Cashier setName(String name) {
        this.name = name;
        return this;
    }

    public Integer getPassword() {
        return password;
    }

    public Cashier setPassword(Integer password) {
        this.password = password;
        return this;
    }
}
