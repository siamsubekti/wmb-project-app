package com.warungmakan.controller;

import com.warungmakan.entities.*;
import com.warungmakan.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*",maxAge = 3600)
@RestController
@RequestMapping("/wmb")
public class WarungMakanController {

    @Autowired
    FoodService foodService;

    @Autowired
    DrinkService drinkService;

    @Autowired
    TableService tableService;

    @Autowired
    OrderService orderService;


    @Autowired
    CashierService cashierService;

    //All Get Mapping
    @GetMapping("/makanan")
    public List<Food> getAllMakanan(){
        return foodService.findAll();
    }

    @GetMapping("/minuman")
    public List<Drinks> getAllMinuman(){
        return  drinkService.findAll();
    }

    @GetMapping("/meja")
    public List<Table> getAllMeja(){
        return tableService.findAll();
    }

    @GetMapping("/pesanan")
    public List<Order> getAllPesanan(){
        return orderService.findAll();
    }

//    @GetMapping("/transaksi")
//    public List<Transaksi> getAllTransaksi(){
//        return  transaksiService.findAll();
//    }

    @GetMapping("/kasir")
    public List<Cashier> getAllKasir(){
        return cashierService.findAll();
    }

//    @GetMapping("/status/{id}")
//    public Optional<StatusMeja> findById(@PathVariable Integer id){return statusMejaService.findById(id);}

//    @GetMapping("/listmeja")
//    public List<Table> listMejaTersedia(){return tableService.listMejaTersedia();}

    //CRUD Order
    @PostMapping("/order")
    public Order createOrder(@RequestBody Order order) throws Exception {
        return orderService.save(order);
    }

    @PutMapping("/pesan/{id}")
    public Order update(@RequestBody Order order, @PathVariable Integer id) throws Exception {
        order.setId(id);
        orderService.save(order);
        return order;
    }


    //CRUD Transaksi
//    @PostMapping("/trans")
//    public  Transaksi create(@RequestBody Transaksi transaksi) throws Exception {
//        return transaksiService.save(transaksi);
//    }

//    @PutMapping("/trans/{id}")
//    public Transaksi update(@RequestBody Transaksi transaksi,@PathVariable Integer id) throws Exception {
//        transaksi.setId(id);
//        transaksiService.save(transaksi);
//        return transaksi;
//    }
}
