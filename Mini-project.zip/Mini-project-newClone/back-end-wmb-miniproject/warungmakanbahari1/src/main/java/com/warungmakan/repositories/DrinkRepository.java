package com.warungmakan.repositories;

import com.warungmakan.entities.Drinks;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DrinkRepository extends JpaRepository<Drinks,Integer> {
}
