package com.warungmakan.repositories;

import com.warungmakan.entities.Cashier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CashierRepository extends JpaRepository<Cashier,Integer> {
}
