package com.warungmakan.service;

import com.warungmakan.entities.Drinks;

import java.util.List;

public interface DrinkService {

    List<Drinks> findAll();
    Drinks save(Drinks drinks);
    Drinks findById (Integer id);
    void delete (Integer id);
}
