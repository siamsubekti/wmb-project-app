package com.warungmakan.service;

import com.warungmakan.entities.Food;

import java.util.List;

public interface FoodService {

    List<Food> findAll();
    Food findById(Integer id);
    Food save(Food food);
    void delete(Integer id);
}
