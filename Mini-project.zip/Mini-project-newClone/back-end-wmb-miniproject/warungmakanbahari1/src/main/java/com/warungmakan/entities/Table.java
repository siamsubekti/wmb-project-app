package com.warungmakan.entities;

import javax.persistence.*;
import java.util.List;

@Entity
@javax.persistence.Table(name = "table")
public class Table {

    @Id
    private Integer id;

    @Column(name = "table_name")
    private String name;

    @Column(name = "chairs_amount")
    private Integer chairsAmount;

    @Column(name = "table_status")
    private String statusTable;

    @OneToMany(mappedBy = "table", cascade = CascadeType.ALL)
    private List<Order> tableOrderList;

    public Table(){}

    public Integer getId() {
        return id;
    }

    public Table setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Table setName(String name) {
        this.name = name;
        return this;
    }

    public Integer getChairsAmount() {
        return chairsAmount;
    }

    public Table setChairsAmount(Integer chairsAmount) {
        this.chairsAmount = chairsAmount;
        return this;
    }

    public String getStatusTable() {
        return statusTable;
    }

    public Table setStatusTable(String meja) {
        this.statusTable = meja;
        return this;
    }
}
