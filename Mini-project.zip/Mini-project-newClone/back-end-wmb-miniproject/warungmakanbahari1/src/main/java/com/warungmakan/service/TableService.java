package com.warungmakan.service;

import com.warungmakan.entities.Table;

import java.util.List;

public interface TableService {

    List<Table> findAll();
    Table findById(Integer id);
    Table save(Table konsumen);
    void delete(Integer id);
}
