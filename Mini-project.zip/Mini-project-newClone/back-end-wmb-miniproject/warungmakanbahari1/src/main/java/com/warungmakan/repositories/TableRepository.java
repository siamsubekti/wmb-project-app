package com.warungmakan.repositories;

import com.warungmakan.entities.Table;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TableRepository extends JpaRepository<Table,Integer> {
//    List<Table> findByIdandStatusMeja (String statusMeja);
    Table findByid (Integer id);
}
