package com.warungmakan.service;

import com.warungmakan.entities.Order;

import java.util.List;

public interface OrderService {

    List<Order> findAll();
    Order findById(Integer id) throws Exception;
    Order save(Order order) throws Exception;
    void delete (Integer id);

}
