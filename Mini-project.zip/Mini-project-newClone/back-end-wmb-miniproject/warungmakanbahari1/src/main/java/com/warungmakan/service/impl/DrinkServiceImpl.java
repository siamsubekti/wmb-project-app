package com.warungmakan.service.impl;

import com.warungmakan.entities.Drinks;
import com.warungmakan.repositories.DrinkRepository;
import com.warungmakan.service.DrinkService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class DrinkServiceImpl implements DrinkService {

    @Autowired
    DrinkRepository drinkRepository;

    @Override
    public List<Drinks> findAll() {
        return drinkRepository.findAll();
    }


    @Override
    public Drinks save(Drinks drinks) {
        return drinkRepository.save(drinks);
    }

    @Override
    public Drinks findById(Integer id) {
        return drinkRepository.getOne(id);
    }

    @Override
    public void delete(Integer id) {
        drinkRepository.deleteById(id);
    }
}
