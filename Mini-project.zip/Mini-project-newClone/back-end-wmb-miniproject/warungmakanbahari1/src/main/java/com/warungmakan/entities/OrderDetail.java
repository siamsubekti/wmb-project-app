package com.warungmakan.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.persistence.Table;


@Entity
@Table(name = "order_detail")
public class OrderDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "food_id", nullable = true)
    private Food itemFood;

    @Column(name = "food_quantity")
    private Integer quantityFood;

    @ManyToOne
    @JoinColumn(name = "drinks_id", nullable = true)
    private Drinks itemDrinks;

    @Column(name = "drink_quantity")
    private Integer quantityDrink;

    @Column(name = "sub_total", nullable = true)
    private Integer subTotal;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order orderDetail;

    public Integer getId() {
        return id;
    }

    public OrderDetail setId(Integer id) {
        this.id = id;
        return this;
    }

    public Food getItemFood() {
        return itemFood;
    }

    public OrderDetail setItemFood(Food itemFood) {
        this.itemFood = itemFood;
        return this;
    }

    public Integer getQuantityFood() {
        return quantityFood;
    }

    public OrderDetail setQuantityFood(Integer quantityFood) {
        this.quantityFood = quantityFood;
        return this;
    }

    public Drinks getItemMinuman() {
        return itemDrinks;
    }

    public OrderDetail setItemMinuman(Drinks itemDrinks) {
        this.itemDrinks = itemDrinks;
        return this;
    }

    public Integer getQuantityDrink() {
        return quantityDrink;
    }

    public OrderDetail setQuantityDrink(Integer quantityDrink) {
        this.quantityDrink = quantityDrink;
        return this;
    }

    public Integer getSubTotal() {
        return subTotal;
    }

    public OrderDetail setSubTotal(Integer subTotal) {
        this.subTotal = subTotal;
        return this;
    }

    public Order getOrderDetail() {
        return orderDetail;
    }

    public OrderDetail setOrderDetail(Order orderDetail) {
        this.orderDetail = orderDetail;
        return this;
    }
}
