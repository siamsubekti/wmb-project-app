-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2019 at 01:24 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warungmakan`
--

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `id` int(11) NOT NULL,
  `cashier_name` varchar(45) DEFAULT NULL,
  `password` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`id`, `cashier_name`, `password`) VALUES
(1, 'Michael', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `drinks`
--

CREATE TABLE `drinks` (
  `id` int(11) NOT NULL,
  `drink_name` varchar(45) DEFAULT NULL,
  `drink_stock` int(11) DEFAULT NULL,
  `drink_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `drinks`
--

INSERT INTO `drinks` (`id`, `drink_name`, `drink_stock`, `drink_price`) VALUES
(1, 'Sweet Ice Tea', 10, 5000),
(2, 'Orange Juice', 10, 5000),
(3, 'Coffee', 10, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `food_name` varchar(45) DEFAULT NULL,
  `food_stock` int(11) DEFAULT NULL,
  `food_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `food_name`, `food_stock`, `food_price`) VALUES
(1, 'Fried Rice', 10, 10000),
(2, 'Fried Chicken', 10, 5000),
(3, 'Seafood Fried Rice', 10, 15000);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `name_customer` varchar(45) DEFAULT NULL,
  `table_id` int(11) NOT NULL,
  `quantity_customer` varchar(45) DEFAULT NULL,
  `total_price` int(20) DEFAULT NULL,
  `transaction_status` varchar(45) DEFAULT NULL,
  `cashier_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name_customer`, `table_id`, `quantity_customer`, `total_price`, `transaction_status`, `cashier_id`) VALUES
(1, 'Aerol', 1, '1', 25000, 'ordered', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `food_id` int(11) NOT NULL,
  `food_quantity` int(11) DEFAULT NULL,
  `drinks_id` int(11) NOT NULL,
  `drink_quantity` int(11) DEFAULT NULL,
  `sub_total` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `food_id`, `food_quantity`, `drinks_id`, `drink_quantity`, `sub_total`, `order_id`) VALUES
(1, 1, 2, 2, 1, 25000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `table`
--

CREATE TABLE `table` (
  `id` int(11) NOT NULL,
  `table_name` varchar(45) DEFAULT NULL,
  `chairs_amount` int(11) DEFAULT NULL,
  `table_status` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `table`
--

INSERT INTO `table` (`id`, `table_name`, `chairs_amount`, `table_status`) VALUES
(1, 'Table 1', 4, 'available'),
(2, 'Table 2', 4, 'available'),
(3, 'Table 3', 4, 'available'),
(4, 'Table 4', 4, 'available'),
(5, 'Table 5', 4, 'available'),
(6, 'Table 6', 4, 'available'),
(7, 'Table 7', 4, 'available'),
(8, 'Table 8', 4, 'available'),
(9, 'Table 9', 4, 'available'),
(10, 'Table 10', 4, 'available'),
(11, 'Table 11', 4, 'available'),
(12, 'Table 12', 4, 'available'),
(13, 'Table 13', 4, 'available'),
(14, 'Table 14', 4, 'available'),
(15, 'Table 15', 4, 'available'),
(16, 'Table 16', 4, 'available'),
(17, 'Table 17', 4, 'available'),
(18, 'Table 18', 4, 'available'),
(19, 'Table 19', 4, 'available'),
(20, 'Table 20', 4, 'available'),
(21, 'Table 21', 4, 'available'),
(22, 'Table 22', 4, 'available'),
(23, 'Table 23', 4, 'available'),
(24, 'Table 24', 4, 'available'),
(25, 'Table 25', 4, 'available'),
(26, 'Table 26', 4, 'available'),
(27, 'Table 27', 4, 'available'),
(28, 'Table 28', 4, 'available'),
(29, 'Table 29', 4, 'available'),
(30, 'Table 30', 4, 'available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drinks`
--
ALTER TABLE `drinks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pesanan_meja1_idx` (`table_id`),
  ADD KEY `fk_pesanan_kasir1_idx` (`cashier_id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pesanan_detail_minuman1_idx` (`drinks_id`),
  ADD KEY `fk_pesanan_detail_makanan1_idx` (`food_id`),
  ADD KEY `fk_pesanan_detail_pesanan1_idx` (`order_id`);

--
-- Indexes for table `table`
--
ALTER TABLE `table`
  ADD PRIMARY KEY (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `fk_pesanan_kasir1` FOREIGN KEY (`cashier_id`) REFERENCES `cashier` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pesanan_meja1` FOREIGN KEY (`table_id`) REFERENCES `table` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `fk_pesanan_detail_makanan1` FOREIGN KEY (`food_id`) REFERENCES `food` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pesanan_detail_minuman1` FOREIGN KEY (`drinks_id`) REFERENCES `drinks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pesanan_detail_pesanan1` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
