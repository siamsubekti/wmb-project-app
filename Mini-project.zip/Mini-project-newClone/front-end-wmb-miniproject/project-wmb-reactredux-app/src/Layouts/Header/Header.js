import React from 'react';
import { Grid } from '@material-ui/core';

function Header() {
    return (
        <Grid>
            <h2 className="header">Warung Makan Bahari</h2>
        </Grid>
    );
}

export default Header;